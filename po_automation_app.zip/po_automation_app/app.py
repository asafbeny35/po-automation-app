from __future__ import annotations

import json
from pathlib import Path
from fastapi import FastAPI, File, Request, UploadFile
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from services.po_parser import parse_purchase_order
from services.greeninvoice import GreenInvoiceClient
from services.sheets import append_purchase_order_row
from services.whatsapp import send_files_via_whatsapp_web

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
OUTPUT_DIR = BASE_DIR / "output"
UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

app = FastAPI(title="PO Automation App")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "result": None})


@app.post("/process", response_class=HTMLResponse)
async def process(request: Request, pdf_file: UploadFile = File(...)):
    file_path = UPLOAD_DIR / pdf_file.filename
    file_path.write_bytes(await pdf_file.read())

    po = parse_purchase_order(file_path)
    client = GreenInvoiceClient()
    delivery_doc, invoice_doc = await client.create_delivery_and_invoice(po, OUTPUT_DIR)
    sheets_result = append_purchase_order_row(
        po=po,
        delivery_id=delivery_doc.document_id,
        invoice_id=invoice_doc.document_id,
        source_pdf_path=file_path,
    )
    await send_files_via_whatsapp_web(
        files=[OUTPUT_DIR / delivery_doc.filename, OUTPUT_DIR / invoice_doc.filename],
        caption=f"מסמכים עבור PO {po.po_number or ''}".strip(),
    )

    result = {
        "purchase_order": po.model_dump(),
        "delivery_document_id": delivery_doc.document_id,
        "invoice_document_id": invoice_doc.document_id,
        "sheets_append_result": sheets_result,
        "saved_files": [delivery_doc.filename, invoice_doc.filename],
    }
    return templates.TemplateResponse(
        "index.html",
        {"request": request, "result": json.dumps(result, ensure_ascii=False, indent=2)},
    )
