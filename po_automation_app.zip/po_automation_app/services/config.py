from __future__ import annotations

import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


def _get_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass
class Settings:
    greeninvoice_api_key: str = os.getenv("GREENINVOICE_API_KEY", "")
    greeninvoice_base_url: str = os.getenv("GREENINVOICE_BASE_URL", "https://api.greeninvoice.co.il/api/v1")
    greeninvoice_delivery_doc_type: str = os.getenv("GREENINVOICE_DELIVERY_DOC_TYPE", "")
    greeninvoice_tax_invoice_doc_type: str = os.getenv("GREENINVOICE_TAX_INVOICE_DOC_TYPE", "")
    greeninvoice_currency: str = os.getenv("GREENINVOICE_CURRENCY", "ILS")
    greeninvoice_vat_percent: float = float(os.getenv("GREENINVOICE_VAT_PERCENT", "18"))
    greeninvoice_documents_endpoint: str = os.getenv("GREENINVOICE_DOCUMENTS_ENDPOINT", "/documents")
    greeninvoice_download_endpoint_template: str = os.getenv(
        "GREENINVOICE_DOWNLOAD_ENDPOINT_TEMPLATE",
        "/documents/download?d={document_id}",
    )

    google_sheets_spreadsheet_id: str = os.getenv("GOOGLE_SHEETS_SPREADSHEET_ID", "")
    google_sheets_range: str = os.getenv("GOOGLE_SHEETS_RANGE", "Sheet1!A:Z")
    google_service_account_json: str = os.getenv("GOOGLE_SERVICE_ACCOUNT_JSON", "./google-service-account.json")
    google_sheets_headers: list[str] = None  # type: ignore[assignment]

    whatsapp_recipient: str = os.getenv("WHATSAPP_RECIPIENT", "")
    whatsapp_storage_state: str = os.getenv("WHATSAPP_STORAGE_STATE", "./whatsapp-state.json")
    whatsapp_headless: bool = _get_bool("WHATSAPP_HEADLESS", False)

    def __post_init__(self) -> None:
        headers = os.getenv("GOOGLE_SHEETS_HEADERS", "")
        self.google_sheets_headers = [h.strip() for h in headers.split(",") if h.strip()]


settings = Settings()
