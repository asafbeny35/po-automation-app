from __future__ import annotations

from datetime import datetime
from pathlib import Path
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build

from .config import settings
from .models import PurchaseOrderData

SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]


def _get_service():
    credentials = Credentials.from_service_account_file(settings.google_service_account_json, scopes=SCOPES)
    return build("sheets", "v4", credentials=credentials)


def build_row(po: PurchaseOrderData, delivery_id: str, invoice_id: str, source_pdf_path: Path) -> list[str]:
    by_header = {
        "Timestamp": datetime.now().isoformat(timespec="seconds"),
        "PO Number": po.po_number or "",
        "PO Date": po.po_date or "",
        "Customer Name": po.customer_name or "",
        "Customer ID": po.customer_id or "",
        "Customer Email": po.customer_email or "",
        "Customer Phone": po.customer_phone or "",
        "Delivery Address": po.delivery_address or "",
        "Subtotal": "" if po.subtotal is None else str(po.subtotal),
        "VAT": "" if po.vat is None else str(po.vat),
        "Total": "" if po.total is None else str(po.total),
        "Items Count": str(len(po.items)),
        "GreenInvoice Delivery ID": delivery_id,
        "GreenInvoice Invoice ID": invoice_id,
        "Source PDF": str(source_pdf_path.name),
    }

    headers = settings.google_sheets_headers or list(by_header.keys())
    return [by_header.get(header, "") for header in headers]


def append_purchase_order_row(po: PurchaseOrderData, delivery_id: str, invoice_id: str, source_pdf_path: Path) -> dict:
    service = _get_service()
    values = [build_row(po, delivery_id, invoice_id, source_pdf_path)]

    return (
        service.spreadsheets()
        .values()
        .append(
            spreadsheetId=settings.google_sheets_spreadsheet_id,
            range=settings.google_sheets_range,
            valueInputOption="USER_ENTERED",
            insertDataOption="INSERT_ROWS",
            body={"values": values},
        )
        .execute()
    )
