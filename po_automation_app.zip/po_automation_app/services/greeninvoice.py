from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import httpx

from .config import settings
from .models import PurchaseOrderData


@dataclass
class CreatedDocument:
    document_id: str
    download_url: str | None = None
    pdf_bytes: bytes | None = None
    filename: str | None = None
    raw_response: dict | None = None


class GreenInvoiceClient:
    def __init__(self) -> None:
        if not settings.greeninvoice_api_key:
            raise RuntimeError("GREENINVOICE_API_KEY is missing.")
        self.base_url = settings.greeninvoice_base_url.rstrip("/")
        self.headers = {
            "Authorization": f"Bearer {settings.greeninvoice_api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    async def create_document(self, payload: dict) -> CreatedDocument:
        url = f"{self.base_url}{settings.greeninvoice_documents_endpoint}"
        async with httpx.AsyncClient(timeout=60) as client:
            response = await client.post(url, headers=self.headers, json=payload)
            response.raise_for_status()
            data = response.json()

        document_id = str(
            data.get("id")
            or data.get("document", {}).get("id")
            or data.get("data", {}).get("id")
            or ""
        )
        if not document_id:
            raise RuntimeError(f"Could not locate document id in Green Invoice response: {data}")

        download_url = f"{self.base_url}{settings.greeninvoice_download_endpoint_template.format(document_id=document_id)}"
        return CreatedDocument(
            document_id=document_id,
            download_url=download_url,
            raw_response=data,
        )

    async def download_document_pdf(self, document_id: str) -> bytes:
        url = f"{self.base_url}{settings.greeninvoice_download_endpoint_template.format(document_id=document_id)}"
        async with httpx.AsyncClient(timeout=60) as client:
            response = await client.get(url, headers=self.headers)
            response.raise_for_status()
            return response.content

    def build_delivery_document_payload(self, po: PurchaseOrderData) -> dict:
        return self._build_document_payload(po=po, document_type=settings.greeninvoice_delivery_doc_type)

    def build_tax_invoice_payload(self, po: PurchaseOrderData, source_document_id: str | None = None) -> dict:
        payload = self._build_document_payload(po=po, document_type=settings.greeninvoice_tax_invoice_doc_type)
        if source_document_id:
            payload.setdefault("linkedDocuments", []).append({"id": source_document_id})
        return payload

    def _build_document_payload(self, po: PurchaseOrderData, document_type: str) -> dict:
        if not document_type:
            raise RuntimeError("Green Invoice document type is missing. Set it in .env.")

        items = []
        for item in po.items:
            items.append(
                {
                    "description": item.description,
                    "quantity": item.quantity,
                    "price": item.unit_price,
                    "total": item.line_total,
                    "currency": settings.greeninvoice_currency,
                }
            )

        if not items and po.total is not None:
            items = [
                {
                    "description": f"הזמנת רכש {po.po_number or ''}".strip(),
                    "quantity": 1,
                    "price": po.total,
                    "total": po.total,
                    "currency": settings.greeninvoice_currency,
                }
            ]

        payload = {
            # NOTE:
            # The exact field names in your Morning account may differ.
            # Verify this payload against the official API docs and adjust once.
            "type": document_type,
            "currency": settings.greeninvoice_currency,
            "vatPercent": settings.greeninvoice_vat_percent,
            "client": {
                "name": po.customer_name,
                "id": po.customer_id,
                "email": po.customer_email,
                "phone": po.customer_phone,
                "address": po.delivery_address,
            },
            "description": f"מבוסס על הזמנת רכש {po.po_number or ''}".strip(),
            "remarks": f"PO {po.po_number or ''} | תאריך {po.po_date or ''}".strip(),
            "items": items,
            "externalReference": po.po_number,
        }
        return payload

    async def create_delivery_and_invoice(self, po: PurchaseOrderData, output_dir: Path) -> tuple[CreatedDocument, CreatedDocument]:
        delivery_payload = self.build_delivery_document_payload(po)
        delivery_doc = await self.create_document(delivery_payload)
        delivery_pdf = await self.download_document_pdf(delivery_doc.document_id)
        delivery_doc.pdf_bytes = delivery_pdf
        delivery_doc.filename = f"delivery_{delivery_doc.document_id}.pdf"
        (output_dir / delivery_doc.filename).write_bytes(delivery_pdf)

        invoice_payload = self.build_tax_invoice_payload(po, source_document_id=delivery_doc.document_id)
        invoice_doc = await self.create_document(invoice_payload)
        invoice_pdf = await self.download_document_pdf(invoice_doc.document_id)
        invoice_doc.pdf_bytes = invoice_pdf
        invoice_doc.filename = f"invoice_{invoice_doc.document_id}.pdf"
        (output_dir / invoice_doc.filename).write_bytes(invoice_pdf)

        return delivery_doc, invoice_doc
