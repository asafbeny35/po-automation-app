from __future__ import annotations

from typing import Any
from pydantic import BaseModel, Field


class POItem(BaseModel):
    description: str
    quantity: float = 1
    unit_price: float = 0
    line_total: float = 0
    sku: str | None = None


class PurchaseOrderData(BaseModel):
    po_number: str | None = None
    po_date: str | None = None
    customer_name: str | None = None
    customer_id: str | None = None
    customer_email: str | None = None
    customer_phone: str | None = None
    delivery_address: str | None = None
    subtotal: float | None = None
    vat: float | None = None
    total: float | None = None
    items: list[POItem] = Field(default_factory=list)
    raw_text: str = ""
    extra: dict[str, Any] = Field(default_factory=dict)
