from __future__ import annotations

import re
from pathlib import Path
import pdfplumber
from .models import PurchaseOrderData, POItem


HEBREW_LABEL_PATTERNS = {
    "po_number": [r"(?:מס[׳'\"]?\s*הזמנת\s*רכש|הזמנת\s*רכש\s*מס[׳'\"]?|PO\s*(?:No\.?|#)?)\s*[:\-]?\s*([A-Za-z0-9\-/]+)"],
    "po_date": [r"(?:תאריך|Date)\s*[:\-]?\s*(\d{1,2}[./-]\d{1,2}[./-]\d{2,4})"],
    "customer_name": [r"(?:לקוח|לכבוד|Customer(?: Name)?)\s*[:\-]?\s*([^\n]{2,80})"],
    "customer_email": [r"([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})"],
    "customer_phone": [r"((?:\+972|0)\d{1,2}[- ]?\d{3}[- ]?\d{4})"],
    "customer_id": [r"(?:ח\.פ\.?|ע\.מ\.?|מס[׳'\"]?\s*לקוח|Customer ID)\s*[:\-]?\s*([0-9\-]{5,15})"],
    "delivery_address": [r"(?:כתובת\s*אספקה|כתובת\s*משלוח|Delivery Address)\s*[:\-]?\s*([^\n]{5,120})"],
    "total": [r"(?:סה[""״']?כ\s*לתשלום|סכום\s*כולל|Grand Total|Total)\s*[:\-₪ ]*([0-9,]+(?:\.\d{1,2})?)"],
    "subtotal": [r"(?:Subtotal|סכום\s*לפני\s*מע[""״']?מ|סה[""״']?כ\s*לפני\s*מע[""״']?מ)\s*[:\-₪ ]*([0-9,]+(?:\.\d{1,2})?)"],
    "vat": [r"(?:מע[""״']?מ|VAT)\s*[:\-₪ ]*([0-9,]+(?:\.\d{1,2})?)"],
}


ITEM_LINE_PATTERN = re.compile(
    r"^(?P<description>[\u0590-\u05FF\w\- /().]{3,80})\s+(?P<qty>\d+(?:\.\d+)?)\s+(?P<unit>\d+(?:,\d{3})*(?:\.\d{1,2})?)\s+(?P<total>\d+(?:,\d{3})*(?:\.\d{1,2})?)$",
    re.MULTILINE,
)


def _normalize_amount(value: str | None) -> float | None:
    if not value:
        return None
    return float(value.replace(",", ""))


def extract_text_from_pdf(pdf_path: str | Path) -> str:
    pages: list[str] = []
    with pdfplumber.open(str(pdf_path)) as pdf:
        for page in pdf.pages:
            pages.append(page.extract_text(x_tolerance=2, y_tolerance=2) or "")
    return "\n".join(pages)


def parse_purchase_order(pdf_path: str | Path) -> PurchaseOrderData:
    text = extract_text_from_pdf(pdf_path)
    data: dict[str, object] = {"raw_text": text}

    for field_name, patterns in HEBREW_LABEL_PATTERNS.items():
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                data[field_name] = match.group(1).strip()
                break

    items: list[POItem] = []
    for match in ITEM_LINE_PATTERN.finditer(text):
        description = match.group("description").strip()
        qty = float(match.group("qty"))
        unit_price = _normalize_amount(match.group("unit")) or 0
        line_total = _normalize_amount(match.group("total")) or 0
        items.append(
            POItem(
                description=description,
                quantity=qty,
                unit_price=unit_price,
                line_total=line_total,
            )
        )

    data["items"] = items

    for amount_field in ("subtotal", "vat", "total"):
        raw = data.get(amount_field)
        if isinstance(raw, str):
            data[amount_field] = _normalize_amount(raw)

    if data.get("subtotal") is None and items:
        data["subtotal"] = round(sum(item.line_total for item in items), 2)

    if data.get("vat") is None and data.get("subtotal") is not None and data.get("total") is not None:
        data["vat"] = round(float(data["total"]) - float(data["subtotal"]), 2)

    return PurchaseOrderData(**data)
